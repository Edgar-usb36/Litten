const botoes = document.querySelectorAll(".botao");
const abas = document.querySelectorAll(".aba-conteudo");
const contadores = document.querySelectorAll(".contador");

const datasObjetivos = [
    new Date("2025-12-31T00:00:00"), 
    new Date("2025-08-01T00:00:00"), 
    new Date("2025-06-15T00:00:00"), 
    new Date("2025-04-30T00:00:00")  
];

// Alternância das abas ao clicar nos botões
botoes.forEach((botao, index) => {
    botao.addEventListener("click", () => {
        botoes.forEach(botao => botao.classList.remove("ativo"));
        abas.forEach(aba => aba.classList.remove("ativo"));

        botao.classList.add("ativo");
        abas[index].classList.add("ativo");
    });
});

// Atualização da contagem regressiva
function atualizarContagem() {
    const tempoAtual = new Date();
    
    contadores.forEach((contador, index) => {
        const diferenca = datasObjetivos[index] - tempoAtual;
        
        if (diferenca > 0) {
            const dias = Math.floor(diferenca / (1000 * 60 * 60 * 24));
            const horas = Math.floor((diferenca % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutos = Math.floor((diferenca % (1000 * 60 * 60)) / (1000 * 60));
            const segundos = Math.floor((diferenca % (1000 * 60)) / 1000);
            
            contador.textContent = `${dias}d ${horas}h ${minutos}m ${segundos}s`;
        } else {
            contador.textContent = "Prazo encerrado";
        }
    });
}

// Atualiza a contagem a cada segundo
setInterval(atualizarContagem, 1000);
